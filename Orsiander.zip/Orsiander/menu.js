const SCROLL_TOP = 180, SCROLL_DIFF = 60;
var Menu, Books, Headings, Chapters, Verses, Y, Handler = 0;

function createOption(chapter = -1, verse = -1) {
    var opt = document.createElement("OPTION");
    if (chapter < 0) return opt;

    opt.value = "k" + ++chapter;

    if (verse < 0) opt.text = chapter;
    else {
        opt.text = ++verse;
        opt.value += "v" + verse;
    }

    return opt;
}

function createVerseOptions(chapter = 1) {
    var node = Headings[--chapter].nextSibling;

    for (var i = -1; node != null && node.tagName != "H2";) {
        if (node.className == "vers") Verses.appendChild(createOption(chapter, ++i));
        node = node.nextSibling;
    }
}

function selectBook() {
    var index = Books.selectedIndex;
    var href = Books.options[index].value;

    if (href) {
        if (window.scrollY > SCROLL_TOP) hideMenu();
        window.open(href + ".htm", index == 0 ? "TOC" : "_blank");
    }

    Books.selectedIndex = 1;
}

function selectChapter() {
    var options = Verses.children;
    options[0].text = "";

    for (var i = options.length; --i > 0;) Verses.removeChild(options[i]);
    createVerseOptions(Chapters.selectedIndex);

    navigate(Chapters, false);
}

function selectVerse() { navigate(Verses); }

function navigate(selector, hide = true) {
    clearDelay();

    var href = location.href;
    var index = href.indexOf("#");
    var options = selector.options;
    var opt = options[selector.selectedIndex];
    var hash = opt.value;

    options[0].text = opt.text;
    selector.selectedIndex = 0;

    location.href = index > -1 ? href.substring(0, index + 1) + hash : href + "#" + hash;

    if (hide) hideMenu();
    else startDelay(3000);
}

function hideMenuDelayed() { hideMenu(); }

function hideMenu() { setMenu("hide"); }

function showMenu() { setMenu(""); }

function setMenu(cls) {
    if (Menu.className == cls) return;

    clearDelay();

    Y = window.scrollY;
    Menu.className = cls;
}

function startDelay(delay = 1500) { if (!Handler) Handler = window.setTimeout(hideMenuDelayed, delay); }

function clearDelay() {
    if (Handler) {
        window.clearTimeout(Handler);
        Handler = false;
    }
}

function selectorMouseDown() {
    this.options[0].text = "";
    clearDelay();
}

function scrollWindow() {
    var y = window.scrollY;
    if (y == Y) return;

    if (y > Y) {
        if (y < SCROLL_TOP) showMenu();
        else startDelay();
    }
    else if (Y - y > SCROLL_DIFF) showMenu();
    else return;

    Y = y;
}

window.onload = function() {
    var links = document.getElementsByTagName("A");
    var href = location.href;
    var i, count;

    href = href.substring(0, href.length - location.search.length - location.hash.length);

    for (i = links.length; --i > -1;) {
        var link = links[i];
        if (link.target == "_blank" && link.href.indexOf(href) == 0) link.target = "";
    }

    Menu = document.getElementById("menu");
    Headings = document.getElementsByTagName("H2");
    Chapters = document.getElementById("chapters");
    Verses = document.getElementById("verses");
    Y = window.scrollY;

    Chapters.appendChild(createOption());
    Verses.appendChild(createOption());

    for (i = -1, count = Headings.length; ++i < count;) Chapters.appendChild(createOption(i));
    createVerseOptions();

    window.onscroll = scrollWindow;
    Chapters.onchange = selectChapter;
    Verses.onchange = selectVerse;

    Chapters.onmousedown = selectorMouseDown;
    Verses.onmousedown = selectorMouseDown;
}