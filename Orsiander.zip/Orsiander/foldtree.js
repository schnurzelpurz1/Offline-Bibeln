/**
 * Foldtree 3.2
 *
 * @copyright    2022 by Fabian Kunz, www.lightshell.ch
 * @package        lightShell core
 * @version        3.1.4
 * @date        14.3.2022
 */

/**
 * Baumobjekt
 *
 * @param {String} id ID-Attribut des Wurzelelements
 * @param {Object} config (optional) Konfigurationsobjekt
 */
Foldtree = function (id, config) {

    // Defaultwerte
    this.vars = {
        params: {
            foldlevels: 0,
            captionlevels: 0,
            contentlevels: 0,
            menulevels: 0,
            iconlevels: 0,
            autonum: 0,
            showlevels: false,
            captionevents: false,
            run: true,
            makebackup: 0,
            storestatus: false,
            explorertree: false,
            buildmenu: false,
            showicons: true
        },
        css: {
            fold: "fold",
            caption: "caption",
            content: "content",
            menu: "menu",
            autonum: "autonum",
            icon: "icon",
            node: "node",
            firstnode: "firstnode",
            lastnode: "lastnode",
            branch: "branch",
            nobranch: "nobranch"
        },
        icons: {
            plus: "plus",
            minus: "minus",
            subminus: "subminus",
            empty: "empty",
            plustext: "Show element",
            minustext: "Hide element",
            emptytext: "Empty element"
        },
        handler: {
            show: function () {
            },
            hide: function () {
            }
        },
        storestatus: "cookie",
        autonumtext: ".. ",
        foldspacing: "",
        nospacelevels: []
    };

    // Defaultwerte überschreiben
    if (typeof config != "undefined") Foldtree._setVars(this.vars, config);

    this.id = id;
    this.node = null;
    this.store = null;
    this.backup = "";
    this.elements = [];
    this.menuitems = [];
    this.count = 0;
    this.status = "";
    this.iconSPAN;
    this.branchDIV;

    Foldtree._registerTree(this);

    /**
     * Baum erstellen
     * @param {Object} config (optional) Konfigurationsobjekt
     */
    this.buildTree = function (config) {
        if (config) Foldtree._setVars(this.vars, config);
        this._build();
    };

    /**
     * Baum neu aufbauen
     * @param {String} src        Backupquelle:
     *                                            - "backup": internes Backup verwenden
     *                                            - "string"    : Backup wird im dritten Parameter als String übergeben
     *                                            - jeder andere Wert:    Es wird kein Backup zurückgeschrieben. Der HTML-Code muss bereits ins Dokument geschrieben sein
     * @param {Object} config    (optional) Initialisierungs-Objekt. Damit können Eigenschaften zur Laufzeit überschrieben werden
     * @param {String} backup    innerHTML der neuen Baumstruktur, falls src = "string"
     */
    this.rebuildTree = function (src, config, backup) {

        // Baum muss bereits erstellt sein
        this.node = Foldtree.$(this.id);
        if (!this.node) alert(Foldtree.globals.messages.invalid_root);
        src = src.toLowerCase();

        // Defaultwerte überschreiben
        if (config) Foldtree._setVars(this.vars, config);

        switch (src) {
            case "backup":
                if (this.backup == "") throw new Error(Foldtree.globals.messages.no_backup.replace("###ID###", this.id));
                this.node.innerHTML = this.backup;
                break;
            case "string":
                if (typeof backup == "undefined") throw new Error(Foldtree.globals.messages.no_backup.replace("###ID###", this.id));
                this.node.innerHTML = backup;
                break;
            default:
        }

        Foldtree.modified = false;
        this._build();
    };

    /**
     * Baum erstellen
     */
    this._build = function () {
        var params = this.vars.params;
        var icons = this.vars.icons;
        var css = this.vars.css;

        if (!params.run) return;

        if (!this.node) this.node = Foldtree.$(this.id);
        if (!this.node) throw new Error(Foldtree.globals.messages.invalid_root.replace("###ID###", this.id));

        // DOM-Unterstützung testen (mindesten Level I)
        if (typeof (document.body.appendChild) == "undefined") throw new Error(Foldtree.globals.messages.no_dom);

        // Backup erstellen: 0 - kein Backup, 1 - immer, 2 - Backup, wenn noch keines vorhanden
        if (params.makebackup == 1 || (params.makebackup == 2 && this.backup == "")) {
            this.backup = this.node.innerHTML;
        }

        // Wenn Baum als Menu benutzt, wird der Foldtree.MenuItem-Handler verwendet
        if (params.buildmenu) params.captionevents = false;

        // interne Variablen
        this.elements = [];
        this.menuitems = [];
        this.count = 0;
        this.status = "";

        // Steuerungsschaltfläche
        this._configIcon(this.iconSPAN = document.createElement("span"), 0, "plus", "plus")

        // Knoten für Astdarstellung
        this.branchDIV = document.createElement("div");
        this.branchDIV.className = css.branch;

        // Frame für Speicherung des Ausklappzustandes holen
        this.store = params.storestatus ? (this.vars.storestatus == "cookie" ? "cookie" : Foldtree._getTarget(this.vars.storestatus, true)) : null;

        Foldtree.modifyBookmarks(document.body);

        var savelink = Foldtree.savelink.node != null;
        this._render(this.node.firstChild, -1, 1, 1, "", true, 0);

        if (!this._restoreStatus()) this.showLevels(params.showlevels);

        // Savelink wurde in diesem Baum gesetzt
        if (Foldtree.savelink.node && !savelink) Foldtree.showSuperior(Foldtree.savelink.node);

        this.node.style.display = "block";
    };

    /**
     * Baum erstellen
     * Ersetzt alle durch fold-Klasse markierten divs durch dynamischen Ausklappbereich
     * @param {Object}    currentNode Ausgangsknoten
     * @param {int}        parentEl Indexnummer des übergeordneten Foldelements oder -1, wenn oberste Hierachieebene
     * @param {int}        level aktuelle Baumebene in der Rekursion
     * @param {int}        num fortlaufende Nummerierung der FoldElemente in einer Ebene (für Auto-Nummerierung)
     * @param {int}        autonum Nummerierungsstring
     * @param {bool}        firstpos true: ist erster Ast des Baums
     * @param {int}        makebranch Steuert die Erstellung der Äste für Baumdarstellung:
     *                            0: Erstellt neuen Container
     *                            1: fügt Inhalte ein
     *                            2: keine Aktion
     */
    this._render = function (currentNode, parentEl, level, num, autonum, firstpos, makebranch) {
        var i, el, currentNum, caption, content, icon, menu, node, textnode, treeblock, pointer, insertspace;
        var hasfolds = false;
        var extra = "";
        var css = this.vars.css;
        var params = this.vars.params;
        var icons = this.vars.icons;

        // letzten Foldbereich innerhalb dieser Ebene suchen
        var lastfold = this._getLastFold(currentNode);
        var lastpos = lastfold == null;

        // Ebene enthält Faltbereiche: Ast auf jeden Fall zeichnen
        if (!lastpos) makebranch = 0;

        while (currentNode) {

            // Leere Textknoten entfernen
            currentNode = Foldtree._cleanup(currentNode);

            if (!currentNode) break;

            // Fold-Bereich:
            if (this._isFold(currentNode)) {

                // führende leere Textknoten und Umbrüche vor Überschrift entfernen
                caption = Foldtree._cleanup(currentNode.firstChild);
                if (!caption) throw new Error(Foldtree.globals.messages.no_caption.replace("###INDEX###", this.count));

                // führende leere Textknoten und Umbrüche vor Inhalt entfernen
                content = Foldtree._cleanup(caption.nextSibling);

                if (currentNode == lastfold) lastpos = true;

                // Für übergeordnete Foldbereiche anmerken
                hasfolds = true;

                // Neuen div für Branch erstellen
                makebranch = 0;

                // Automatische Nummerierung
                currentNum = autonum ? autonum + this.vars.autonumtext.substr(0, 1) + num : num;

                this.elements[this.count] = el = new Foldtree.Element(currentNode, this, level, parentEl, this.count++, num++, firstpos, lastpos);

                // Überschrift verarbeiten
                // Behandlung von Tabellen
                switch (caption.tagName) {
                    case "TABLE":
                        caption = Foldtree._cleanup(caption.firstChild);

                        if (caption.tagName == "CAPTION") caption = caption.firstChild;
                        else for (i = 0; i < 3; i++) caption = Foldtree._cleanup(caption.firstChild);					// <thead> oder <tbody>: <tr> und <td> auslassen
                        break;

                    case "DIV":
                        if ((caption.currentStyle ? caption.currentStyle : getComputedStyle(caption, null))["display"] == "flex") caption = Foldtree._cleanup(caption.firstChild);		// Flex-Container
                        break;
                }

                // Überschrift reiner Textknoten oder Bild oder Objekt (z.B. Flash)? In div-Knoten einpacken
                if (caption.nodeType == 3 || caption.tagName == "IMG" || caption.tagName == "OBJECT") {
                    node = document.createElement("div");
                    caption.parentNode.insertBefore(node, caption);
                    node.appendChild(caption);
                    caption = node;
                }

                el.caption = caption;

                // Autonummerierung einfügen
                if (params.autonum === true || params.autonum >= level) {
                    node = document.createElement("span");
                    this._setCSS(node, level, "autonum", "");
                    textnode = document.createTextNode(currentNum + this.vars.autonumtext.substr(1));
                    node.appendChild(textnode);
                    caption.insertBefore(node, caption.firstChild);
                    el.num = node;
                }

                // Baumabzweiger für Explorerstil: 4 Typen: erster, mittlerer, letzter, einziger
                if (params.explorertree) {
                    if (firstpos) {
                        extra = css.firstnode;
                        if (lastpos) extra += " " + css.lastnode;
                    } else extra = lastpos ? css.lastnode : css.node;
                }

                firstpos = false;

                menu = caption.href && params.buildmenu;
                if (!menu) this._setCSS(caption, level, "caption", extra);

                // Schaltfläche erzeugen
                el.icon = icon = this._createIcon(caption, level, "minus");
                if (!params.captionevents && icon) el._addEvent(icon);
                else el._addEvent(caption);

                // Inhaltsbereich vorhanden?
                if (content) {
                    this.status += "1";		// Initialisieren des Ausklappzustandes

                    if (menu) this.menuitems.push(new Foldtree.MenuItem(caption, level, this, el, true, extra));

                    this._addContent(el, content);

                    // Foldbereich rekursiv durchsuchen
                    el.hasfolds = this._render(el.content.firstChild, el.index, level + 1, 1, currentNum, false, 0);
                }

                // Fold-Bereich ohne Inhalt
                else {
                    el.status = 0;
                    this.status += "0";

                    // Menuevent ohne folding
                    if (menu) this.menuitems.push(new Foldtree.MenuItem(caption, level, this, el, true, extra));
                }

                el._setIcon(true);
                currentNode.className = this._levelCSS(level, "fold") + currentNode.className.substr(css.fold.length);

                // Abstände zwischen Foldbereichen
                if (this.vars.foldspacing) {
                    insertspace = true;

                    // Ist für aktuellen Level Foldspacing aktiviert
                    for (i = 0; i < this.vars.nospacelevels.length; i++) {
                        if (this.vars.nospacelevels[i] == level) {
                            insertspace = false;
                            break;
                        }
                    }

                    // Abstand einfügen?
                    if (insertspace) {
                        // Kommt noch was ausser leere Textknoten?
                        pointer = currentNode;
                        while (pointer.nextSibling && pointer.nextSibling.nodeType == 3 && pointer.nextSibling.data.search(/\S/) == -1) pointer = pointer.nextSibling;
                        if (pointer.nextSibling) currentNode.style.marginBottom = this.vars.foldspacing;
                    }
                }
            }

            // Kein Fold-Bereich:
            else {
                // Menu-Link:
                if (currentNode.href && params.buildmenu) this.menuitems.push(new Foldtree.MenuItem(currentNode, level, this, el, false, extra));

                // Enthält weitere Unterknoten:
                else if (currentNode.tagName && Foldtree.nestingTags.indexOf("|" + currentNode.tagName + "|") > -1) this._render(currentNode.firstChild, parentEl, level, num, autonum, true, 2);

                // Wrap für Darstellung der Baumstruktur
                if (params.explorertree) {
                    if (makebranch == 0) {
                        treeblock = this.branchDIV.cloneNode(true);
                        treeblock.className = (lastpos || firstpos) ? css.nobranch : css.branch;
                        currentNode.parentNode.insertBefore(treeblock, currentNode);
                        makebranch = 1;
                    }

                    // Element in Block einfügen
                    if (makebranch == 1) currentNode = Foldtree._domWrap(treeblock, currentNode);
                }
            }
            currentNode = currentNode.nextSibling;
        }
        return hasfolds;
    };

    /**
     * Prüfen, ob Knoten Faltbereich ist
     * @param {Object}    node
     * @return {bool}    true: er ist
     */
    this._isFold = function (node) {
        return node.className && node.className.indexOf(this.vars.css.fold) == 0;
    };

    /**
     * Knoten von Faltbereichen innerhalb derselben Ebene suchen
     * @param {Object}    node
     * @return {Array}    Faltknoten
     */
    this._getLastFold = function (node) {
        var last;
        while (node) {
            if (this._isFold(node)) last = node;
            node = node.nextSibling;
        }
        return last;
    };

    /**
     * Inhaltsknoten erzeugen
     * Wenn neben der Überschrift weitere Knoten im Faltknoten sind, werden diese in Inhaltsknoten verschoben
     * @param {Object}    el Faltelement
     * @param {Object}    node 1. Inhaltsknoten
     * @return {Array}    Faltknoten
     */
    this._addContent = function (el, node) {
        var css = this.vars.css;

        var content = document.createElement("div");
        this._setCSS(content, el.level, "content", "");
        el.content = content;
        el.savecss = content.className;

        if (node) {
            var next;
            el.hascontent = true;
            el.node.insertBefore(content, node);

            // Nachfolgende Knoten in Inhaltsknoten verschieben
            do {
                next = node.nextSibling;
                content.appendChild(node);
            } while (node = next);
        } else el.node.appendChild(content);

        // Wrap für Darstellung der Baumstruktur
        if (this.vars.params.explorertree) {
            var branch = document.createElement("div");
            branch.className = el.lastpos ? css.nobranch : css.branch;
            el.node.insertBefore(branch, content);
            branch.appendChild(content);
        }
    };

    /**
     * Icon erzeugen
     * Fügt dem Dateinamen bei Bedarf Indexnummer hinzu: "plus.gif" -> "plus1.gif"
     *
     * @param {Object}    parent Knoten (Überschrift), dem das Icon eingesetzt wird
     * @param {int}        level Leveltiefe
     * @param {String}    type "plus", "minus" oder "empty"
     *
     */
    this._createIcon = function (parent, level, type) {
        var params = this.vars.params;
        if (!params.showicons) return null;

        var icon = this.iconSPAN.cloneNode(true);

        this._configIcon(icon, level, type, type)
        parent.insertBefore(icon, parent.firstChild);

        return icon;
    };

    this._configIcon = function (icon, level, type, text) {
        var icons = this.vars.icons;
        this._setCSS(icon, level, "icon", icons[type]);
        icon.title = icons[text + "text"];
    };

    /**
     * Stellt Klassenattribut (CSS) eines Knotens gemäss Verschachtelungstiefe ein
     * @param {Object}    node zu modifizierender Knoten
     * @param {int}        level aktuelle Baumebene
     * @param {String}  type Leveltyp: Bezeichner in vars.css
     * @param {String}    extra zusätzliche Klassenauszeichnungen
     */
    this._setCSS = function (node, level, type, extra) {
        node.className = this._appendCSS(this._levelCSS(level, type), extra);
    };

    this._levelCSS = function (level, type) {
        var l = this.vars.params[type + "levels"];
        var c = this.vars.css[type];

        return l === undefined || c === undefined ? type : level && (l === true || l >= level) ? c + level : c;
    };

    this._appendCSS = function (css0, css1) {
        return css0 ? css1 ? css0 + " " + css1 : css0 : css1;
    };

    /**
     * Ersetzt letzte CSS-Klasse innerhalb class-Attribut
     * Wird die gesuchte Klasse nicht gefunden, wird Attribut um Ersatzklasse erweitert
     * @param {Object}    node zu modifizierender Knoten
     * @param {String}    srch gesuchte Klasse
     * @param {String}    rep Ersatzklasse
     */
    this._replaceCSS = function (node, srch, rep) {
        node.className = node.className.replace(eval("/(^| )" + srch + "$/"), "");
        if (rep) node.className += " " + rep;
    };

    /**
     * Untergeordnete FoldElemente suchen
     * @param {Object} Ausgangselement
     * @return {Array} FoldElemente
     */
    this._getBranch = function (el) {
        var list = this.elements;
        var filtered = [el];
        var l = el.level;

        for (var i = el.index + 1; i < list.length; i++) {

            // Ende des Astes ist erreicht, wenn das nächste Element auf derselben oder einer höheren Ebene gefunden wird
            if (list[i].level <= l) break;
            filtered.push(list[i]);
        }
        return filtered;
    };

    /**
     * Verschiedene Astinformationen ermitteln
     * @param {Object}    el Elternelement oder false für Wurzelelement
     * @param {Object}    node Elternknoten
     * @return {Object}    {Array} siblings benachbarte Faltelemente in der 1. Ebene
     *                    {Int} level Anzahl Faltelemente in der 1. Ebene
     *                    {Int} total Anzahl Faltelemente insgesamt
     */
    this._getBranchInfo = function (el, node) {
        var list, parent;
        if (el) {
            list = this._getBranch(el);
            list.shift();
            parent = el.index;
        } else {
            list = this.elements;
            parent = -1;
        }
        var r = {siblings: [], level: 0, total: list.length};

        for (var i = 0; i < r.total; i++) {
            el = list[i];
            if (el.parent == parent) {
                if (el.node.parentNode == node) r.siblings.push(el);
                r.level++;
            }
        }

        return r;
    };

    /**
     * Ast Zeichnen
     * @param {Object}    node Elternelement oder false für Wurzelelement
     * @param {String}    draw CSS-Klasse zum Zeichnen
     * @param {String}    erase CSS-Klasse zum Löschen
     * @param {String}    next DOM-Property zum Ansteuern des nächsten Elements
     */
    this._drawBranch = function (node, draw, erase, next) {
        while (node && node.className == erase) {
            node.className = draw;
            node = node[next];
        }
    };

    /**
     * Ausschnitt aus Liste aller Faltelemente verschieben
     * Alle Elemente müssen im selben Ast befinden (parent).
     * Es wird der Index, die Parents und die Autonummerierung, wenn eingeschaltet, aktualisiert
     * @param {int}    first erstes Element
     * @param {int}    last letztes Element + 1
     * @param {int}    parent Index des Elternelements
     * @param {int}    s_index Verschiebung des Index nach oben (+) / nach unten (-)
     * @param {int}    s_order Verschiebung der Sortierung nach oben (+) / nach unten (-)
     */
    this._shiftIndex = function (first, last, parent, s_index, s_order) {
        var list = this.elements;
        var el;

        for (var i = first; i < last; i++) {
            el = list[i];
            if (el.parent == parent) el.order += s_order;			// Sortierung ändert sich nur für nachfolgende benachbarte Elemente im selben Ast
            else if (el.parent > parent) el.parent += s_index;		// Elternelement ändert sich nur von Kindelementen von nachfolgenden Ästen
            el.index += s_index;
        }
    };

    /**
     * Autonummerierung aktualisieren
     * @param {int}    first erstes Element
     * @param {int}    last letztes Element + 1
     */
    this._updateAutonum = function (first, last) {
        var autonum = this.vars.params.autonum;
        if (!autonum) return;
        if (autonum === true) autonum = 1000000;

        var list = this.elements;
        var el;
        var s1 = this.vars.autonumtext.substr(0, 1);
        var s2 = this.vars.autonumtext.substr(1);
        var num, node;

        for (var i = first; i < last; i++) {
            el = list[i];
            if (el.level > autonum) continue;

            node = el.num;
            num = el.order + s2;

            while (el.parent != -1) {
                el = list[el.parent];
                num = el.order + s1 + num;
            }

            node.innerHTML = num;
        }
    };

    /**
     * Anzeigen / Verbergen von Hierachieebenen
     * @param {mixed} level    Zahl:    Anzahl Ebenen, die angezeigt werden
     *                                    false:    Alle Ebenen werden versteckt. Entspricht 0
     *                                    true:    Alle Ebenen werden angezeigt
     */
    this.showLevels = function (depth) {
        if (!this.count) return;

        if (depth === true) depth = 1000000;
        else if (depth === false) depth = 0;

        var list = this.elements;
        var el;

        for (var i = 0; i < this.count; i++) {
            el = list[i];
            if (el.level <= depth) el._show();
            else el._hide();
            depth = depth;
        }
    };

    /**
     * Stellt Ausklapp-Status nach URL-Wechsel wieder her.
     * Wird kein Status gefunden, wird neuer erstellt.
     * Wird der Status in einem Frame gespeichert, wird in diesem Frame ein Objekt mit Namen FoldtreeStatus erstellt
     * Der Status wird als Stringfolge von 0 und 1 gespeichert: 0 = eingeklappt, 1 = ausgeklappt
     */
    this._restoreStatus = function () {
        if (!this.store) return;

        // Status in Cookie mit Name = Baum-ID?
        if (this.store === "cookie") {
            var cookie = Foldtree.getCookie(this.id);

            // Stimmt Länge mit Anzahl FoldElementen überein: gespeicherten Status verwenden
            if (cookie.length == this.count) this.status = cookie;

            // Sonst Cookie erstellen
            else {
                document.cookie = this.id + "=" + this.status;
                return false;
            }
        }

        // Speicherung in Frame
        else {

            // Menudaten nicht vorhanden? Erstellen
            if (!this.store.FoldtreeStatus) this.store.FoldtreeStatus = {};

            // Menustatus nicht vorhanden? Erstellen
            if (!this.store.FoldtreeStatus[this.id]) {
                this.store.FoldtreeStatus[this.id] = this.status;
                return false;
            }

            // Stimmt Länge mit Anzahl FoldElementen nicht überein: verwerfen
            if (this.store.FoldtreeStatus[this.id].length != this.count) return false;

            // gespeicherten Status verwenden
            this.status = this.store.FoldtreeStatus[this.id];
        }

        // Status wiederherstellen
        for (var i = 0; i < this.status.length; i++) {
            if (this.status.charAt(i) == "0") this.elements[i]._hide();
            else this.elements[i]._show();
        }
        return true;
    };

    /**
     * Speichert Baumansicht bei jedem Ein-/Ausklappvorgang
     * @param {String}    status: 0 = eingeklappt, 1 = ausgeklappt
     * @param {int}        index Nummer des FoldElements
     */
    this._setStatus = function (status, index) {
        if (!this.store) return;

        var store = this.vars.storestatus;
        var status = this.status.substr(0, index) + status + this.status.substr(index + 1);

        this._saveStatus(status);
    };

    /**
     * Speichert gesamte Baumansicht
     *
     * @param {String}    status Status aller Baumknoten
     */
    this._saveStatus = function (status) {
        this.status = status;
        if (this.store === "cookie") document.cookie = this.id + "=" + status;
        else this.store.FoldtreeStatus[this.id] = status;
    };
};

/**
 * Ausklappbereich
 * @param {Object}    foldnode Ausklappbereich
 * @param {Object}    tree Baum der den Ausklappbereich enthält
 * @param {int}        level Ebene in Baumhierarchie
 * @param {Object}    parent übergeordneter Ausklappbereich
 * @param {int}        index fortlaufende Nummerierung
 * @param {int}        order Sortierposition innerhalb der Ebene
 * @param {bool}    firstpos zeigt an, ob das Element am Anfang eines Astes ist (für Baumdarstellung).
 * @param {bool}    lastpos zeigt an, ob das Element am Ende eines Astes ist (für Baumdarstellung).
 */
Foldtree.Element = function (foldnode, tree, level, parent, index, order, firstpos, lastpos) {

    /**
     * onClick-event anhängen
     * @param {Object} node Knoten, dem das Event angehängt wird
     */
    this._addEvent = function (node) {
        node.style.cursor = "pointer";
        Foldtree._addEvent(node, "click", this._handler);
    };

    /**
     * Ein-/Ausklappen
     * Deaktiviert Link temporär, wenn Icon angeklickt
     * @param {Object} e Event
     */
    this._handler = function (e) {
        ev = document.all ? window.event.srcElement : e.target;

        // Link angeklickt?
        while (ev != foldnode && !ev.href) ev = ev.parentNode;
        thisobj._toggle();

        // Icon geklickt (IE)
        if (tree.vars.params.buildmenu && "A" == ev.parentNode.tagName) Foldtree._lockLink(ev.parentNode);
    };

    /**
     * Blendet Inhalte ein/aus
     */
    this._toggle = function () {
        if (this.status) this._hide();
        else this._show();
    };

    /**
     * Inhalte anzeigen durch setzten der richtigen Klasse (Level) an und Icon wechseln
     */
    this._show = function () {
        if (this.hascontent && !this.status) {
            this.content.className = this.savecss;
            this._setIcon(true);
            this.tree._setStatus("1", this.index);
            this.status = 1;
        }

        this.tree.vars.handler.show(this);
    };

    /**
     * Inhalte verstecken durch setzten der Klasse "hidden" und Icon wechseln
     */
    this._hide = function () {
        if (this.hascontent && this.status) {
            this.savecss = this.content.className;
            this.content.className = Foldtree.globals.hideclass;
            this._setIcon(false);
            this.tree._setStatus("0", this.index);
            this.status = 0;
        }

        this.tree.vars.handler.hide(this);
    };

    /**
     * Inhalte anzeigen/verbergen
     * @param {bool} visible true: anzeigen; false: verbergen
     */
    this._showHide = function (visible) {
        if (visible) this._show();
        else this._hide();
    };

    /**
     * Setzt korrektes Icon
     * @param {bool} visible true = [-], false = [+]
     */
    this._setIcon = function (visible) {
        var params = this.tree.vars.params;
        if (!params.showicons) return;

        if (!this.hascontent) this.tree._configIcon(this.icon, this.level, "empty", "empty");
        else if (visible) this.tree._configIcon(this.icon, this.level, params.explorertree && this.hasfolds ? "subminus" : "minus", "minus");
        else this.tree._configIcon(this.icon, this.level, "plus", "plus");
    };

    this.tree = tree;				// Foldtree-Objekt, zu dem Element gehört
    this.level = level;			// Ebene in dem Element steht (unterste = 1)
    this.index = index;			// Index im Array tree.elements
    this.order = order;			// Sortierposition innerhalb des Astes und Ebene
    this.parent = parent;		// Index des übergeordneten Faltelements oder -1
    this.firstpos = firstpos;	// Element steht am Anfang eines Astes
    this.lastpos = lastpos;		// Element steht am Ende eines Astes
    this.hasfolds = false;		// Element hat weitere Faltelemente
    this.hascontent = false;	// Element hat Inhalt

    this.node = foldnode;		// Knoten von gesamtem Faltelement
    this.caption = null;		// Knoten von Überschrift
    this.content = null;		// Inhaltsknoten (wenn vorhanden)
    this.icon = null;			// Knoten für Schaltfläche
    this.num = null;			// Knoten von Autonummerierung (<span>, wenn eingeschaltet)

    this.savecss = "";
    this.status = 1;		// Einklappzustand: 1 = ausgeklappt; 0 = eingeklappt
    this.href = "";

    var thisobj = this;
};

/**
 * Menuelement
 * @param {Object}    node Link-Knoten
 * @param {int}        level Hierachieebene, in der sich der Link befindet
 * @param {Object}    tree Baum in dem sich der Link befindet
 * @param {Object}    fold FoldElement, wenn sich der Link in der Überschrift befindet
 * @param {bool}    iscaption true: Link befindet sich in der Überschrift
 * @param {String}    Spezielle CSS Auszeichnung
 */
Foldtree.MenuItem = function (node, level, tree, fold, iscaption, extra) {

    /**
     * Aktionen beim Anklicken eines Menulinks
     * Ein-/Ausklappen wenn Link in Überschrift
     * Deaktiviert Link temporär, wenn Icon angeklickt
     *
     * @param {Object} e Event
     */
    this._handler = function (e) {
        var ev = document.all ? window.event.srcElement : e.target;
        node.blur();

        // Link in Überschrift
        if (iscaption) {

            // Icon angeklickt? Link deaktivieren (der FoldElement-Handler wird bei Mozilla/Opera nach diesem Event ausgeführt)
            if (ev == fold.icon) {
                Foldtree._lockLink(node);
                return;
            }

            // neutraler Link oder bereits aktiv: nur ein-/ausklappen
            if (node.href == "javascript:;" || (Foldtree.globals.activelink.lock && node == Foldtree.savelink.node)) {
                Foldtree._lockLink(node);
                fold._toggle();
            } else fold._show();
        }

        // Link in Inhaltsbereich
        else if (node.href == "javascript:;" || (Foldtree.globals.activelink.lock && node == Foldtree.savelink.node)) {
            Foldtree._lockLink(node);
        }

        if (node.href != "javascript:;") Foldtree.setActiveLink(node);
    };

    this.fold = fold;

    // CSS-Klasse überschreiben
    tree._setCSS(node, level, "menu", extra, false);

    // Aktiver Link?
    if (Foldtree.globals.activelink.on) {
        var tgt = Foldtree._getTarget(node.target, true);

        if (tgt) {
            var href = node.href;
            var tgthref = tgt.location.href;

            if (!Foldtree.globals.activelink.matchquery) {
                href = node.href.split("?")[0];
                tgthref = tgt.location.href.split("?")[0];
            }

            if (decodeURI(href) == decodeURI(tgthref)) Foldtree.setActiveLink(node);
        }
    }

    Foldtree._addEvent(node, "click", this._handler);
};

/**
 * Statische Eigenschaften
 * Eigenschaften des globals-Objekts können zur Laufzeit mit Foldtree.setGlobals() gesetzt werden.
 * Restliche Parameter für internen Gebrauch
 */

/**
 *  Einfacher DOM-Zugriff
 */
Foldtree.$ = function (id) {
    return document.getElementById(id) || document.getElementsByName(id)[0];
};

Foldtree.globals = {
    hideclass: "hidden",
    activelink: {
        on: false,
        css: "active",
        lock: false,
        matchquery: true
    },
    highlight: {
        on: true,
        css: "highlight",
        interval: 500,
        repeating: 3
    },
    messages: {
        no_dom: "No DOM support.",
        invalid_root: "Invalid root node [ ###ID### ]",
        no_caption: "Node [ ###INDEX### ] has no caption",
        bookmark_not_found: "Bookmark ####MARK### not found",
        no_backup: "No backup found for tree [ ###ID### ]"
    }
};

Foldtree.collection = [];
Foldtree.highlight = {node: null, savecss: "", css: "", handler: null, count: 0};
Foldtree.savelink = {node: null, css: ""};
Foldtree.clicked = {node: null, href: ""};
Foldtree.printwin = null;
Foldtree.modified = false;
Foldtree.nestingTags = "|DIV|TABLE|THEAD|TBODY|TFOOT|TR|TD|TH|";

/**
 * Globale Eigenschaften überschreiben
 * @param {object} vars Globale Parameter. Es müssen nicht alle Eigenschaften von Foldtree.globals gesetzt werden.
 */
Foldtree.setGlobals = function (vars) {
    Foldtree._setVars(Foldtree.globals, vars);
};

/**
 * Variablen rekursiv setzen
 * Es werden nur Variablen gesetzt die im Zielobjekt bereits definiert wurden
 * @param {Object} obj Zielobjekt, dessen Member gesetzt werden
 * @param {Object} vars Quellobjekt
 */
Foldtree._setVars = function (obj, vars) {
    var v;

    for (var i in vars) {
        if (typeof obj[i] == "undefined") continue;
        v = vars[i];

        if (obj[i] instanceof Array) {
            if (!(v instanceof Array)) continue;
        } else if (obj[i] instanceof Function) {
            if (!(v instanceof Function)) continue;
        } else if (obj[i] instanceof Object) {
            if (typeof v == "object") Foldtree._setVars(obj[i], v);		// Problem mit instanceof in FF3
            continue;
        }
        obj[i] = v;
    }
};

/**
 * Baum registrieren
 * Bäume mit derselben Tree-ID werden nur 1x registriert.
 * @param {Object} tree Foldtree-Objekt
 */
Foldtree._registerTree = function (tree) {
    var col = Foldtree.collection;
    for (var i = 0; i < col.length; i++) {
        if (col[i].id == tree.id) return;
    }
    Foldtree.collection.push(tree);
};

/**
 * Parst GET Parameter und weist sie dem params-Objekt der durch den Parameter "FOLDTREE" bestimmten Bäume zu.
 * Aufruf vor Foldtree.buildTrees()
 */
Foldtree.parseGetVars = function () {
    var s = location.search;
    if (s.length == 0) return;

    var temp = {};
    var trees = "";
    var params = s.substr(1).split("&");

    // GET Variablen einlesen
    var pos, p, v;
    for (var i = 0; i < params.length; i++) {
        pos = params[i].indexOf("=");
        if (pos == -1) continue;

        p = params[i].substr(0, pos).toLowerCase();
        v = params[i].substr(pos + 1).toLowerCase();

        if (p == "foldtree") trees = v;		// Bäume, dessen Parameter gesetzt werden sollen
        else temp[p] = v;							// übrige Parameter
    }

    trees = Foldtree._findTrees(trees);

    // Wird kein Baum gefunden, versuchen, den ersten zu nehmen
    if (!trees) trees = Foldtree.collection.length > 0 ? [Foldtree.collection[0]] : [];

    // Parameter der betreffenden Bäume setzen
    var j, tp;
    for (i = 0; i < trees.length; i++) {
        tp = trees[i].vars.params;
        for (j in temp) {
            if (typeof tp[j] != "undefined" && (temp[j] == "true" || temp[j] == "false" || parseInt(temp[j]) >= -1)) tp[j] = eval(temp[j]);
        }
    }
};

/**
 * Sucht Baum in der collection aufgrund der ID
 * @param {String}        id    des Baumes:
 *                                - Name:            Baum mit diesem ID-Attribut
 *                                - Numerisch:    Baum mit dieser Indexnummer. Werden in der Reihenfolge ihrer Erstellung vergeben (von 0 an)
 *                                - "all":            Alle Bäume erhalten dieselben GET Parameter
 *
 * @return {mixed} Array mit Foldtree-Objekten. Wird kein Baum gefunden, wird null zurückgegeben.
 */
Foldtree._findTrees = function (id) {
    var col = Foldtree.collection;
    if (id == "all") return col;

    // Numerische Angabe
    if (id.search(/^\d{1,2}$/) != -1 && id < col.length) return [col[id]];

    // String-Angabe
    for (var i = 0; i < col.length; i++) {
        if (col[i].id == id) return [col[i]];
    }
};

/**
 * Alle Bäume erstellen, öffnen und, wenn vorhanden, Bookmark anspringen
 */
Foldtree.buildTrees = function () {
    var col = Foldtree.collection;
    for (var i = 0; i < col.length; i++) {
        col[i].buildTree();
    }

    // Sprung ausführen, wenn Seitenadresse Bookmark enthält
    if (location.href.indexOf("#") > -1) Foldtree.jump(location.href, "_self");
};

/**
 * Ersetzt Hyperlinks mit Bookmarks (href="dieseSeite#mybookmark") durch entsprechende jump() Aufrufe
 * @param {Object} node Links innerhalb dieses Knotens werden untersucht
 */
Foldtree.modifyBookmarks = function (node) {
    if (Foldtree.modified) return;
    var linkobj = node.getElementsByTagName("a");
    var tgt;

    for (var i = 0; i < linkobj.length; i++) {

        // keine Bookmark-Adresse, oder bereits umgebogen?
        if (linkobj[i].href.indexOf("#") == -1 || linkobj[i].href.indexOf("javascript:") == 0) continue;

        // Zielframe ermitteln und Link-Adresse auf eigene Funktion umbiegen.
        if (tgt = Foldtree._getTarget(linkobj[i].target, false)) {
            linkobj[i].href = "javascript: Foldtree.jump('" + linkobj[i].href + "', '" + tgt + "');";
            linkobj[i].target = "_self";
        }
    }
    Foldtree.modified = true;
};

/**
 * Ermittelt Zielfenster eines Links unter Berücksichtigung des <BASE> Tags
 * @param {String}    tgt Target-Attribut eines Links
 * @param {bool}        mode    Rückgabe: window-Referenz (true) oder  String (false)
 * @return {mixed}    window-Referenz / String
 */
Foldtree._getTarget = function (tgt, mode) {

    // Falls Target nicht spezifiziert und ein Base-Target vorhanden, dieses nehmen
    var base = document.getElementsByTagName("base");
    if (base.length > 0 && base[0].target) {
        tgt = (tgt == "") ? base[0].target : tgt;
    }

    // Kein Zugriff auf diese Fenster möglich
    if (tgt == "_top" || tgt == "_blank") return false;

    // Target-String in Fenster-Referenz konvertieren
    else if (mode) {
        switch (tgt) {
            case "_parent":
                return parent;
            case "_self":
                return self;
            case "":
                return self;
            default:
                return this._getFrame(tgt);
        }
    }

    // Kein Basetarget, kein Target: eigenes Fenster
    else if (tgt == "") return "_self";

    return tgt;
};

/**
 *    Fensterhierarchie durchsuchen
 * @param {String}        tgt Target-Attribut eines Links
 * @return {Object}    Refrenz auf Fenster
 */
Foldtree._getFrame = function (tgt) {
    var win = self;
    while (!win.frames[tgt] && win != top) {
        win = win.parent;
    }
    return win.frames[tgt];
};

/**
 * Blendet einen bestimmten Ast mitsamt seiner Unterästen ein.
 *
 * @param {DOM}    node Knoten in einem Ast.
 */
Foldtree.showBranch = function (node) {
    Foldtree._showHideBranch(node, true);
};

/**
 * Verbirgt einen bestimmten Ast mitsamt seiner Unteräste.
 *
 * @param {DOM}    node Knoten in einem Ast.
 */
Foldtree.hideBranch = function (node) {
    Foldtree._showHideBranch(node, false);
};

/**
 * Ast ein-/ausblenden
 * Start der Rekursion
 * @param {Object}    node Knoten in einem Ast
 * @param {bool}        true: Ast wird eingeblendet. false: Ast wird ausgeblendet.
 */
Foldtree._showHideBranch = function (node, show) {
    var el = Foldtree.getElement(node);
    if (!el) return;

    var list = el.tree._getBranch(el);
    for (var i = list.length; --i > -1;) list[i]._showHide(show);
};

/**
 * Einzigen Ast anzeigen
 * Der fold-Bereich in dem sich der Knoten befindet und seine übergeordneten FoldElemente bleiben angezeigt, der Rest des Baumes wird ausgeblendet.
 * @param {node}    Knoten im eingeblendeten Ast.
 */
Foldtree.showNoneBut = function (node) {
    var el = Foldtree.getElement(node);
    if (!el) return;

    el.tree.showLevels(false);
    Foldtree.showSuperior(el);
};

/**
 * Zeigt übergeordnete FoldElemente bis zur Wurzel des Baumes an.
 * Verwendung für verborgene Bookmarks und aktiven Link
 * @param {Object} el Ausgangsknoten / FoldElement
 */
Foldtree.showSuperior = function (el) {
    if (!(el instanceof Foldtree.Element)) {
        el = Foldtree.getElement(el);
        if (!el) return;
    }
    var tree = el.tree;
    var list = tree.elements;
    var i = el.index;
    while (i != -1) {
        list[i]._show();
        i = list[i].parent;
    }
};

/**
 * HTML-Struktur in Faltelement einfügen und rendern
 * @param {node}        Bezugsknoten: es wird das erste übergeordnete Faltelement oder das Wurzelelement gesucht
 * @param {string}    mode Einfügemodus:
 *                            "insert": der Code wird am Ende des Inhaltsbereichs eingefügt; für Wurzelelement identisch mit "after"
 *                            "before": der Code wird vor das Faltelement bzw. am Anfang des Wurzelelements eingefügt
 *                            "after": der Code wird nach dem Faltelement bzw. am Ende des Wurzelelements eingefügt
 *                            "replace": der Code ersetzt das Faltelement; nicht unterstützt für Wurzelelement. Verwende stattdessen rebuildTree()
 * @param {string}    html HTML-Code
 */
Foldtree.insertHTML = function (node, mode, html) {
    if (!html) return;

    // Container zum Rendern des HTML-Codes vorbereiten
    var div = document.createElement("div");
    div.innerHTML = html;
    var child = div.firstChild;
    if (!Foldtree._cleanup(child)) return;

    var el, index, parent, level, order;
    var tree = Foldtree._getTree(node);
    if (!tree) return;

    var list = tree.elements;
    var css = tree.vars.css;
    var explorer = tree.vars.params.explorertree;

    var firstpos = false;
    var lastpos = false;

    var hasfolds = tree._getLastFold(div.firstChild) != null;

    var protectlast = 1;		// 1: eingefügter Code wird am Ende geschützt

    Foldtree.modified = false;
    Foldtree.modifyBookmarks(div);

    // Einfügeposition ist Faltelement
    if (el = Foldtree.getElement(node)) {
        parent = el.parent;
        level = el.level;
        index = el.index;
        order = el.order;
        node = el.node;

        switch (mode) {
            case "append":
                parent = el.index;
                level++;
                index++;
                lastpos = true;
                var siblings;

                // Hat bereits Inhalt
                if (el.hascontent) {

                    // es kommen Faltelemente hinzu -> Ast um Inhaltsblöcke am Ende zeichnen
                    if (hasfolds) {
                        el.hasfolds = true;
                        tree._drawBranch(el.content.lastChild, css.branch, css.nobranch, "previousSibling");
                    }

                    // Element hat bereits Kinder -> Indexverschiebung und Sortierung ermitteln
                    var info = tree._getBranchInfo(el, el.content);
                    siblings = info.siblings.pop();
                    index += info.total;
                    order = info.level;
                }

                // Leeres Faltelement -> zuerst Inhalt erzeugen
                else {
                    tree._addContent(el);
                    el.hascontent = true;
                    order = 0;
                }

                el.status = 0;
                el._show();
                el.content.appendChild(div);
                el = siblings;
                break;

            case "before":
                order--;
                firstpos = el.firstpos;
                node.parentNode.insertBefore(div, node);
                break;

            case "after":
                child = tree._getBranch(el).pop();
                index = child.index + 1;
                lastpos = el.lastpos;
                var sibling;
                if (sibling = node.nextSibling) node.parentNode.insertBefore(div, sibling);
                else node.parentNode.appendChild(div);
                break;

            case "replace":
                firstpos = el.firstpos;
                lastpos = el.lastpos;
                el = null;
                order--;
                node.parentNode.insertBefore(div, node);
                Foldtree.removeBranch(node, true);
                break;

            default:
                return;
        }
    }

    // Einfügeposition ist Wurzelelement
    else {
        parent = -1;
        level = 1;
        index = 0;
        order = 0;
        node = tree.node;
        var info = tree._getBranchInfo(false, node);
        if (!info.siblings.length) firstpos = lastpos = true;

        switch (mode) {
            case "before":
                firstpos = true;
                el = info.siblings.shift();
                if (node.firstChild) node.insertBefore(div, node.firstChild);
                else node.appendChild(div);
                break;

            case "append":
            case "after":
                el = info.siblings.pop();
                order = info.level;
                index = tree.count;
                lastpos = true;
                node.appendChild(div);
                break;

            default:
                return;
        }
    }

    // eingefügter Code hat Verbindungslinien zum alten Baum:
    if (explorer) {
        if (hasfolds) {
            if (firstpos && el) {
                el.firstpos = false;

                // Ast für Inhaltsblöcke am Anfang des Baums zeichnen (zwischen altem und neuem Anfang)
                tree._drawBranch(el.node.previousSibling, css.branch, css.nobranch, "previousSibling");

                // Anfang des alten Baums modifizieren
                tree._replaceCSS(el.node.firstChild, css.firstnode, (el.lastpos ? "" : css.node));
            }

            if (lastpos) {
                protectlast = 0;

                // Vorangehendes Element modifizieren
                if (el) {
                    el.lastpos = false;

                    // Ast der Treeblöcke, die nicht mehr am Ende stehen, zeichnen
                    tree._drawBranch(div.previousSibling, css.branch, css.nobranch, "previousSibling");

                    // Abzweigung von vorangehendem Element ändern und Ast um Inhaltsblock zeichnen
                    node = el.node.firstChild;
                    tree._replaceCSS(node, css.lastnode, (el.firstpos ? "" : css.node));
                    if (el.hascontent) node.nextSibling.className = css.branch;
                }
            }
        }

        // Keine Faltelemente in erster Ebene: keine Äste zeichnen
        else if (firstpos || lastpos) protectlast = 0;
    }

    //  nicht am Ende eines Astes: Ende für Rendering schützen
    if (protectlast) {
        node = document.createElement("div");
        node.className = css.fold;
        node.appendChild(document.createTextNode("x"));
        div.appendChild(node);
    }

    // HTML-Code rendern
    var temptree = new Foldtree("", tree.vars);
    temptree.iconSPAN = tree.iconSPAN;
    temptree.branchDIV = tree.branchDIV;
    temptree._render(div.firstChild, -1, level, 1, "", firstpos, 0);

    var count = temptree.count - protectlast;
    var last = index + count;
    var status = temptree.status.substr(protectlast);
    var templist = temptree.elements.splice(0, count);

    // Schutz wieder entfernen
    if (protectlast) div.removeChild(div.lastChild);

    // neue Faltelemente in Baum einfügen
    tree.elements = list.slice(0, index).concat(templist, list.slice(index));
    tree.count += count;
    tree._saveStatus(tree.status.substr(0, index) + status + tree.status.substr(index));

    // Elemente des eingefügten Baums anpassen
    tree._shiftIndex(index, last, -1, index, order);

    // Rootelemente zählen (Verschiebung der Sortierung), parent und tree-Referenz anpassen
    order = 0;
    for (var i = index; i < last; i++) {
        el = tree.elements[i];
        if (el.parent == -1) {
            el.parent = parent;
            order++;
        }
        el.tree = tree;
    }

    // Nachfolgende Elemente anpassen
    tree._shiftIndex(last, tree.count, parent, count, order);

    // Autonummerierung von neuen und nachfolgenden Elementen aktualisieren
    tree._updateAutonum(index, tree.count);

    // Knoten innerhalb des divs direkt davor verschieben
    parent = div.parentNode;
    while (node = div.firstChild) {
        parent.insertBefore(node, div);
    }
    parent.removeChild(div);	// Leeres div entfernen

    tree.menuitems = tree.menuitems.concat(temptree.menuitems);
};

/**
 * Ast entfernen
 * Das Faltelement mit allen Unterelementen  wird gelöscht.
 * @param {node}    node Bezugsknoten: es wird das erste übergeordnete Faltelement gesucht
 * @param {bool}    keeptree (nur für interne Aufrufe) Explorerbaum nicht modifizieren
 */
Foldtree.removeBranch = function (node, keeptree) {
    var el = Foldtree.getElement(node);
    if (!el) return;

    var tree = el.tree;
    var count = tree._getBranch(el).length;
    var index = el.index;
    var list = tree.elements;

    // Faltelemente entfernen
    list.splice(index, count);
    tree.count -= count;
    tree._saveStatus(tree.status.substr(0, index) + tree.status.substr(index + count));

    // Index und Autonummerierung nachfolgender Faltelemente anpassen
    tree._shiftIndex(index, tree.count, el.parent, -count, -1);
    tree._updateAutonum(index, tree.count);

    // Explorerbaum aktualisieren
    if (tree.vars.params.explorertree && !keeptree) {
        var css = tree.vars.css;
        var siblings = tree._getBranchInfo(list[el.parent], el.node.parentNode).siblings;

        if (el.lastpos) {

            // Vorangehenden Nachbarn suchen und zum letzten Element machen
            var prevEl = siblings.pop();
            if (prevEl) {
                prevEl.lastpos = true;

                // Abzweigung von vorangehendem Element ändern und Ast um Inhaltsblock löschen
                tree._replaceCSS(prevEl.caption, "node", css.lastnode);
                if (prevEl.hascontent) prevEl.node.firstChild.nextSibling.className = css.nobranch;

                // Ast zum gelöschten Element löschen
                tree._drawBranch(prevEl.node.nextSibling, css.nobranch, css.branch, "nextSibling");
            }

            // Übergeordnetes Element bearbeiten, wenn vorhanden und wenn gelöschtes Element nicht isoliert ist
            else if (el.parent != -1 && !el.firstpos) {
                var parentEl = list[el.parent];
                parentEl.hasfolds = false;

                // Element enthält noch Treeblöcke -> Ast löschen
                if (node = el.node.previousSibling) tree._drawBranch(node, css.nobranch, css.branch, "previousSibling");
                else {
                    node = parentEl.node;
                    node.removeChild(node.lastChild);
                    parentEl.hascontent = false;
                }

                parentEl._setIcon(parentEl.status);
            }
        }

        // 1. Element wurde gelöscht
        else if (el.firstpos) {

            // das nachfolgende Element zum Ersten machen
            var nextEl = siblings.shift();
            if (nextEl) {
                nextEl.firstpos = true;

                // Abzweigung von nächstem Element ändern
                nextEl.node.firstChild.className += " " + css.firstnode;

                // Ast zum gelöschten Element löschen
                tree._drawBranch(nextEl.node.previousSibling, css.nobranch, css.branch, "previousSibling");
            }
        }
    }

    // DOM-Knoten entfernen
    el.node.parentNode.removeChild(el.node);
    el = null;

    // Menuelemente filtern
    if (tree.vars.params.buildmenu) {
        items = tree.menuitems;
        var filtered = [];
        for (var i = 0; i < items.length; i++) {
            if (items[i].fold) filtered.push(items[i]);
        }
        tree.menuitems = filtered;
    }
};

/**
 * Übergeordneten Foldbereich suchen
 * @param {Object} node Ausgangsknoten
 * @return {Object} FoldElement oder null
 */
Foldtree.getElement = function (node) {
    var tree = Foldtree._getTree(node);
    if (!tree) return;

    var elements = tree.elements;
    while (node && node != tree.node) {
        for (var i = elements.length; --i > -1;) {
            var el = elements[i];
            if (el.node == node) return el;
        }
        node = node.parentNode;
    }
};

/**
 * Übergeordneten Baum suchen
 * @param {Object} node Ausgangsknoten
 * @return {Object} Baumobjekt oder null
 */
Foldtree._getTree = function (node) {
    var list = Foldtree.collection;
    var i;
    while (node != document.body) {
        for (var i = 0; i < list.length; i++) {
            if (list[i].node == node) return list[i];
        }
        node = node.parentNode;
    }
};

/**
 * Entfernt führende leere Textknoten und Umbrüche
 * @param {Object} node Ausgangsknoten
 * @return {Object} erster echter Knoten auf derselben Ebene
 */
Foldtree._cleanup = function (node) {

    // Leere Textknoten, Kommentare und Umbrüche am Anfang entfernen
    while (node && ((node.nodeType == 3 && node.data.search(/\S/) == -1) || node.nodeType == 8 || (node.nodeType == 1 && node.tagName == "BR"))) {
        next = node.nextSibling;
        node.parentNode.removeChild(node);
        node = next;
    }

    // wenn Textknoten mit Inhalt, führende Whitespaces entfernen
    if (!node || node.nodeType != 3) return node;
    var text = node.data;
    while (text.charCodeAt(0) < 33) text = text.substr(1);
    node.data = text;
    return node;
};

/**
 * Eventhandler registrieren
 * @param {Object} node    DOM-Knoten
 * @param {String} ev        Eventname ohne "on", klein geschrieben (z.B. click, mousedown etc.)
 * @param {Func} func        Funktion die bei Auftreten des Events ausgeführt wird
 */
Foldtree._addEvent = window.addEventListener ? function (node, ev, func) {
    node.addEventListener(ev, func, false);
} : function (node, ev, func) {
    node.attachEvent("on" + ev, func);
};

/**
 * Umgibt DOM Node mit einem anderen (appendChild)
 * @param {Object}    container Kontainerknoten
 * @param {Object}    content Knoten, der in Container eingesetzt wird
 * @return {Object}    container
 */
Foldtree._domWrap = function (container, content) {
    var temp = content.parentNode.removeChild(content);
    container.appendChild(temp);
    return container;
};

/**
 * Deaktiviert Link für 50ms
 * Verhindert, dass Browser zur verweisenden URL wechselt
 * @param {Object} node Zu deaktivierender Link
 */
Foldtree._lockLink = function (node) {
    if (Foldtree.clicked.node) return;
    Foldtree.clicked.node = node;
    Foldtree.clicked.href = node.href;
    node.href = "javascript:;";
    window.setTimeout("Foldtree._unlockLink()", 50);
};

/**
 * Gegenstück zu Foldtree._lockLink()
 */
Foldtree._unlockLink = function () {
    if (!Foldtree.clicked.node) return;
    Foldtree.clicked.node.href = Foldtree.clicked.href;
    Foldtree.clicked.node = null;
};

/**
 * Setzt Link auf "aktiv"
 * @param {Object}    node Link, der aktiv gesetzt wird
 */
Foldtree.setActiveLink = function (node) {
    if (!Foldtree.globals.activelink.on) return;

    // Bestehenden Link zurücksetzen
    if (Foldtree.savelink.node) Foldtree.savelink.node.className = Foldtree.savelink.css;

    // Neuen Link zwischenspeichern
    Foldtree.savelink = {node: node, css: node.className};
    node.className += " " + Foldtree.globals.activelink.css;
};

/**
 * Setzt Link mit angegebener Adresse auf "aktiv"
 * @param {Object}    node Link, der aktiv gesetzt wird
 */
Foldtree.setActiveLinkHref = function (href) {
    if (!Foldtree.globals.activelink.on) return;

    // Links in allen Bäumen durchsuchen
    var node, links = [];
    var c1 = Foldtree.collection.length;
    var c2;
    for (var i = 0; i < c1; i++) {
        node = Foldtree.collection[i].node;
        if (!node) continue;
        links = node.getElementsByTagName("a");

        // Adressvergleich mit jedem Link
        c2 = links.length;
        for (var j = 0; j < c2; j++) {
            if (links[j].href == href) {
                Foldtree.setActiveLink(links[j]);
                return;
            }
        }
    }
};

/**
 * Sprung zu Bookmark
 * Blendet darüberliegende FoldElemente ein und startet Highlighting. Wenn Ziel ein anderer Frame, wird versucht die dortige jump()-Funktion auszuführen
 * @param{String} url (string)
 * @param{String} url (string)
 */
Foldtree.jump = function (url, tgt) {

    // Zielframe ermitteln:
    var win = Foldtree._getTarget(tgt, true);
    if (!win) return;

    // Adressvergleich ohne Bookmark
    var loc = Foldtree._splitURL(url);
    var winloc = Foldtree._splitURL(win.location.href);

    // Andere Seite: normal ansurfen, wenn nicht bereits geladen (Opera Endlosschlaufe vermeiden)
    if (loc.url != winloc.url) {
        win.location.href = url;
        return;
    }

    // Bookmark in anderem Frame: versuchen dortige Funktion zu benutzen
    if (win.name != self.name) {
        if (win.Foldtree.jump) win.Foldtree.jump(url, "_self");
        else win.location.href = url;
        return;
    }

    Foldtree.highlightNode(loc.hash);

    if (loc.hash == winloc.hash) location.href = "#";		// Opera Quirks: mehrmaliges Anspringen desselben Bookmarks funktioniert nicht
    location.href = "#" + loc.hash;
};

/**
 * Knoten anzeigen und Highlighting starten
 * @param {String}    id ID / Name des Knotens, der zum Leuchten gebracht werden soll
 * @param {bool}        on true: Globale Einstellung (globals.highlight.on) für dieses Event überschreiben
 */
Foldtree.highlightNode = function (id, on) {
    var node = Foldtree.$(id);

    // Bookmark nicht gefunden: Meldung ausgeben
    if (!node) throw new Error(Foldtree.globals.messages.bookmark_not_found.replace("###MARK###", id));

    Foldtree.showSuperior(node);

    if (!Foldtree.globals.highlight.on && !on) return;

    // Schon am Blinken? Blinken ausschalten und Klasse zurücksetzen
    var h = Foldtree.highlight;
    if (h.handler) {
        clearInterval(h.handler);
        h.node.className = h.savecss;
    }

    // Blinkobjekt und seine Klasse zwischenspeichern
    h.node = node;
    h.savecss = node.className;
    h.css = h.savecss + (h.savecss ? " " : "") + Foldtree.globals.highlight.css;
    h.count = Foldtree.globals.highlight.repeating * 2 - 1;
    node.className = h.css;
    h.handler = setInterval("Foldtree.doHighlight()", Foldtree.globals.highlight.interval);
};

/**
 * Knoten highlighten
 * Effekt wird durch Wechseln des Klassennamens in Intervallen erreicht
 */
Foldtree.doHighlight = function () {
    var h = Foldtree.highlight;
    if (h.count != 0) {
        h.node.className = h.node.className == h.savecss ? h.css : h.savecss;
        h.count--;
    }

    // Blinken stoppen
    else {
        clearInterval(h.handler);
        h.node.className = h.savecss;
    }
};

/**
 * Zerlegt URL in Adresse + Hash
 * @param{String} url (string)
 * @return {Object} {url, hash}
 */
Foldtree._splitURL = function (url) {
    var hash = "";
    url = decodeURI(url);

    var pos = url.indexOf("#");
    if (pos > 0) {
        hash = url.substr(pos + 1);
        url = url.substr(0, pos);
    }

    return {url: url, hash: hash};
};

/**
 * Öffnet aktuelle Seite in neuem Fenster, zeigt Bäume mit den angegebenen Parametern an und startet Druckvorgang.
 * @param {string}    params    Treeparameter (siehe: Foldtree.parseGetVars()).
 */
Foldtree.print = function (params) {
    var l = location;
    var s = l.search;
    var h = l.hash;
    s += s.length ? "&" : "?";
    if (params) params += "&";
    s += params + "storestatus=0&showlevels=true";
    var url = l.href.substr(0, l.href.length - l.search.length - h.length) + s + h;
    Foldtree.printwin = window.open(url, 'Anzeige', 'top=0, left=0, status=no, toolbar=no, menubar=no, location=no, resizable=yes, height=400, width=650');
    window.setTimeout("Foldtree.printwin.print()", 2000);
};

/**
 * Cookie-Wert extrahieren
 */
Foldtree.getCookie = function (id) {
    if (!navigator.cookieEnabled) return "";
    var cookie = document.cookie;
    id += "=";
    var start = cookie.indexOf(id) + id.length;
    var end = cookie.indexOf(";", start);
    if (end == -1) end = cookie.length;
    return cookie.substring(start, end);
};