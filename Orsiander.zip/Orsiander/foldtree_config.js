tocTree = new Foldtree("toc", {
	params : {
		foldlevels : 3,
		storestatus : true
	},
	css: {
		fold: "level",
		caption: "title",
		content: "entries"
	},
	icons : {
		plustext : "Ausklappen",
		minustext : "Einklappen"
	},
	foldspacing : "0",
	nospacelevels : [0]
});

window.onload = function () { Foldtree.buildTrees(); }