var Toc = [
    ["index", "Alle Bücher"],
    ["", "--- Altes Testament ---"],
    ["at_1mos", "Das erste Buch Mose"],
    ["at_2mos", "Das zweite Buch Mose"],
    ["at_3mos", "Das dritte Buch Mose"],
    ["at_4mos", "Das vierte Buch Mose"],
    ["at_5mos", "Das fünfte Buch Mose"],
    ["at_jos", "Das Buch Josua"],
    ["at_ri", "Das Buch der Richter"],
    ["at_rut", "Das Buch Ruth"],
    ["at_1sam", "Das erste Buch Samuel"],
    ["at_2sam", "Das zweite Buch Samuel"],
    ["at_1koen", "Das erste Buch der Könige"],
    ["at_2koen", "Das zweite Buch der Könige"],
    ["at_1chr", "Das erste Buch der Chronik"],
    ["at_2chr", "Das zweite Buch der Chronik"],
    ["at_esra", "Das Buch Esra"],
    ["at_neh", "Das Buch Nehemia"],
    ["at_est", "Das Buch Esther"],
    ["at_hi", "Das Buch Hiob"],
    ["at_ps", "Der Psalter"],
    ["at_spr", "Die Sprüche Salomos"],
    ["at_pred", "Der Prediger Salomo"],
    ["at_hld", "Das Hohelied Salomos"],
    ["at_jes", "Der Prophet Jesaja"],
    ["at_jer", "Der Prophet Jeremia"],
    ["at_klgl", "Die Klagelieder Jeremias"],
    ["at_hes", "Der Prophet Hesekiel"],
    ["at_dan", "Der Prophet Daniel"],
    ["at_hos", "Der Prophet Hosea"],
    ["at_joel", "Der Prophet Joel"],
    ["at_am", "Der Prophet Amos"],
    ["at_obd", "Der Prophet Obadja"],
    ["at_jon", "Der Prophet Jona"],
    ["at_mi", "Der Prophet Micha"],
    ["at_nah", "Der Prophet Nahum"],
    ["at_hab", "Der Prophet Habakuk"],
    ["at_zef", "Der Prophet Zephanja"],
    ["at_hag", "Der Prophet Haggai"],
    ["at_sach", "Der Prophet Sacharja"],
    ["at_mal", "Der Prophet Maleachi"],
    ["", "--- Neues Testament ---"],
    ["nt_mt", "Das Evangelium des Matthäus"],
    ["nt_mk", "Das Evangelium des Markus"],
    ["nt_lk", "Das Evangelium des Lukas"],
    ["nt_joh", "Das Evangelium des Johannes"],
    ["nt_apg", "Die Apostelgeschichte des Lukas"],
    ["nt_roem", "Der Brief des Paulus an die Römer"],
    ["nt_1kor", "Der erste Brief des Paulus an die Korinther"],
    ["nt_2kor", "Der zweite Brief des Paulus an die Korinther"],
    ["nt_gal", "Der Brief des Paulus an die Galater"],
    ["nt_eph", "Der Brief des Paulus an die Epheser"],
    ["nt_phil", "Der Brief des Paulus an die Philipper"],
    ["nt_kol", "Der Brief des Paulus an die Kolosser"],
    ["nt_1thes", "Der erste Brief des Paulus an die Thessalonicher"],
    ["nt_2thes", "Der zweite Brief des Paulus an die Thessalonicher"],
    ["nt_1tim", "Der erste Brief des Paulus an Timotheus"],
    ["nt_2tim", "Der zweite Brief des Paulus an Timotheus"],
    ["nt_tit", "Der Brief des Paulus an Titus"],
    ["nt_phim", "Der Brief des Paulus an Philemon"],
    ["nt_1petr", "Der erste Brief des Petrus"],
    ["nt_2petr", "Der zweite Brief des Petrus"],
    ["nt_1joh", "Der erste Brief des Johannes"],
    ["nt_2joh", "Der zweite Brief des Johannes"],
    ["nt_3joh", "Der dritte Brief des Johannes"],
    ["nt_hebr", "Der Brief an die Hebräer"],
    ["nt_jak", "Der Brief des Jakobus"],
    ["nt_jud", "Der Brief des Judas"],
    ["nt_off", "Die Offenbarung des Johannes"]
];

Books = document.getElementById("books");

for (var i = -1, count = Toc.length; ++i < count;) {
    var entry = Toc[i];
    var opt = document.createElement("OPTION");

    opt.value = entry[0];
    opt.text = entry[1];
    Books.appendChild(opt);
}

Books.selectedIndex = 1;
Books.onchange = selectBook;
Books.onmousedown = clearDelay;