const SCROLL = 90, DELAY = 3000;
var Navigation, NavHeight, NavGap, Books, CurrentBook = 0, Chapters = [], CS, VS, Y, Handler = -1, Visibility = true;

function Chapter(index, node) {

    this.Find = function(y) {
        for (var i = this.Verses.length; --i > -1;) {
            var child = this.Verses[i];
            if (y < child.offsetTop) continue;

            return i;
        }

        return y < this.Node.offsetTop ? -2 : -1;
    }

    this.SetOptions = function () { VS.SetOptions(this.Index, this.Verses.length); }

    this.Index = index;
    this.Node = node;
    this.Verses = [];

    CS.AddOption(this.Index);
    while ((node = node.nextSibling) != null && node.tagName != "H2") { if (node.className == "vers") this.Verses.push(node); }
}

function Selector(id, name, type) {

    this.Dec = function() { this.Change(-1); }

    this.Inc = function() { this.Change(1); }

    this.Change = function (offset) {
        var id = this.Select(this.Index);
        if (id == null) return;

        var node = document.getElementById(id);
        if (node == null) return;

        var y = node.offsetTop;

        if (offset > 0 ? y < getY() + NavHeight + NavGap : y > getY() + NavHeight - NavGap) this.Set(offset);
        else {
            if (this.Type < 1) VS.Select(0);

            clearHide();
            window.scrollTo(0, Y = y - NavHeight);
        }
    }

    this.Set = function(offset = 0) {
        var id = this.Select(offset == 0 ? this.Node.selectedIndex - 1 : this.Index + offset);
        if (id == null) {
            if (this.Type > 0 && CS.Set(offset)) {
                var chapter = Chapters[CS.Index];
                chapter.SetOptions();
                id = this.Select(offset > 0 ? 0 : chapter.Verses.length - 1)
            }
            else return false;
        }
        else if (this.Type < 1) Chapters[CS.Index].SetOptions();

        clearHide();

        var node = document.getElementById(id);
        if (node != null) window.scrollTo(0, Y = node.offsetTop - NavHeight);

        return true;
    }

    this.Select = function(index) {
        this.Node.selectedIndex = 0;

        var i = index + 1;
        if (i > 0 && i < this.Options.length) {
            this.SetCurrentOption(index);
            return this.Options[i].value;
        }

        return null;
    }

    this.SetOptions = function(index, count) {
        var i;
        for (i = this.Options.length; --i > 0;) this.Node.removeChild(this.Options[i]);
        for (i = -1; ++i < count;) this.AddOption(index, i);

        this.SetCurrentOption();
    }


    this.AddOption = function (chapter, verse = -1) {
        var opt = this.CreateEmptyOption();
        opt.value = "k" + ++chapter;

        if (verse < 0) opt.text = chapter;
        else {
            opt.text = ++verse;
            opt.value += "v" + verse;
        }

        this.Node.appendChild(opt);
    }

    this.CreateEmptyOption = function () { return document.createElement("OPTION"); }

    this.SetCurrentOption = function(index = 0) { this.Options[0].text = this.Name + " " + ((this.Index = index) + 1); }

    this.Node = document.getElementById(id);
    this.Options = this.Node.options;
    this.Name = name;
    this.Index = -1;
    this.Type = type;

    this.Node.appendChild(this.CreateEmptyOption());
    this.Node.onmousedown = clearHide;
}

function selectBook() {
    var index = Books.selectedIndex;
    if (index == CurrentBook) return;

    var href = Books.options[index].value;
    if (href) {
        if (getY() > SCROLL) startHide();
        window.open(href + ".htm", index == 0 ? "TOC" : "_blank");
    }

    Books.selectedIndex = CurrentBook;
}

function hideNavigation() { setNavigation("hide"); }

function showNavigation() {
    setNavigation("");
    if (Y > SCROLL) startHide();
}

function setNavigation(cls) {
    clearHide();
    Y = getY();

    if (Visibility && Navigation.className != cls) Navigation.className = cls;
}

function startHide() { if (Handler < 0 && Navigation.className != "hide") Handler = window.setTimeout(hideNavigation, DELAY); }

function clearHide() {
    if (Handler > -1) {
        window.clearTimeout(Handler);
        Handler = -1;
    }
}

function getY() { return Math.round(window.scrollY); }

function scrollWindow() {
    var y = getY();
    if (y == Y) return;

    for (var c = 0, v = 0, i = Chapters.length, pos = y + NavHeight; --i > -1;) {
        var chapter = Chapters[i], index = chapter.Find(pos);
        if (index < -1) continue;

        c = chapter.Index;
        v = Math.max(index, 0);
        break;
    }

    if (c != CS.Index) {
        CS.Select(c);
        Chapters[c].SetOptions();
    }
    VS.Select(v);

    if (y > Y) {
        if (y > SCROLL) { if (y - Y > SCROLL) hideNavigation(); }
        else showNavigation();
    }
    else if (Y - y > SCROLL) showNavigation();
}

function setVisibility(ev) {
    var third = window.innerWidth / 3, x = ev.pageX;
    Visibility = x < third || x > third + third;
}

window.onload = function() {
    var nodes = document.getElementsByTagName("A"), node;
    var href = location.href;
    var i, count;

    href = href.substring(0, href.length - location.search.length - location.hash.length);
    for (i = nodes.length; --i > -1;) { if ((node = nodes[i]).target == "_blank" && node.href.indexOf(href) == 0) node.target = ""; }

    CurrentBook = 1;
    href = href.substring(href.lastIndexOf("/") + 1, href.length - 4);
    for (i = -1, count = (nodes = Books.options).length; ++i < count;) {
        if ((node = nodes[i]).value != href) continue;

        CurrentBook = i;
        break;
    }

    Books.selectedIndex = CurrentBook;
    NavHeight = (NavGap = Math.floor((Navigation = document.getElementById("navigation")).offsetHeight / 2)) * 3;
    CS = new Selector("chapters", "Kapitel", 0);
    VS = new Selector("verses", "Vers", 1);

    for (i = -1, count = (nodes = document.getElementsByTagName("H2")).length; ++i < count;) Chapters.push(new Chapter(i, nodes[i]));

    Books.onchange = selectBook;
    Books.onmousedown = clearHide;

    Y = getY() + SCROLL + 1;
    window.onscroll = scrollWindow;
    window.onwheel = setVisibility;
    window.onpointerdown = setVisibility;
    scrollWindow();
}